<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\OrdentrabajoRepository")
 */
class Ordentrabajo
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Serie", inversedBy="ordentrabajos")
     * @ORM\JoinColumn(nullable=false)
     */
    private $serie;

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\Usuario", inversedBy="ordentrabajos")
     */
    private $usuarios;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $indicaciones_cliente;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $averias_detectadas;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Delegacion", inversedBy="ordentrabajos")
     * @ORM\JoinColumn(nullable=false)
     */
    private $delegacion;


    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Prioridad", inversedBy="ordentrabajos")
     * @ORM\JoinColumn(nullable=false)
     */
    private $prioridad;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Marca", cascade={"persist"})
     */
    private $marca;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Modelo", cascade={"persist"})
     */
    private $Modelo;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\PartNumber")
     */
    private $partnumber;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Tipo", inversedBy="ordentrabajos")
     * @ORM\JoinColumn(nullable=false)
     */
    private $tipo;

    /**
     * @ORM\Column(type="datetime")
     */
    private $fecha_entrada;

    /**
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $fecha_salida;

    /**
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $fecha_fin;

    /**
     * @ORM\Column(type="boolean")
     */
    private $PresupuestoAceptado;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    private $Actualizar;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Situacion", inversedBy="ordentrabajos")
     * @ORM\JoinColumn(nullable=false)
     */
    private $situacion;

    /**
     * @ORM\Column(type="string", length=10, nullable=true)
     */
    private $n_orden;

    /**
     * @ORM\Column(type="string", length=10)
     */
    private $n_caso;

    /**
     * @ORM\Column(type="string", length=20, nullable=true)
     */
    private $color;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $TrabajosaRealizar;

    /**
     * @ORM\Column(type="string", length=40, nullable=true)
     */
    private $n_serie;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Materiales", mappedBy="OrdenTrabajo")
     * @ORM\JoinColumn(onDelete="CASCADE")
     */
    private $materiales;

    /**
     * @ORM\Column(type="string", length=500, nullable=true)
     */
    private $observaciones;

    /**
     * @ORM\Column(type="string", length=1000, nullable=true)
     */
    private $observaciones_int;

    /**
     * @ORM\Column(type="string", length=20, nullable=true)
     */
    private $n_presupuesto;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $accesorios;

    /**
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $fechaCompraEquipo;

    public function __construct()
    {
        $this->usuarios = new ArrayCollection();
        $this->fecha_entrada = new \DateTime();
        $this->fecha_salida = null;
        $this->setPresupuestoAceptado(false);
        $this->materiales = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getSerie(): ?serie
    {
        return $this->serie;
    }

    public function setSerie(?serie $serie): self
    {
        $this->serie = $serie;

        return $this;
    }

    /**
     * @return Collection|usuario[]
     */
    public function getUsuarios(): Collection
    {
        return $this->usuarios;
    }

    public function addUsuario(usuario $usuario): self
    {
        if (!$this->usuarios->contains($usuario)) {
            $this->usuarios[] = $usuario;
        }

        return $this;
    }

    public function removeUsuario(usuario $usuario): self
    {
        if ($this->usuarios->contains($usuario)) {
            $this->usuarios->removeElement($usuario);
        }

        return $this;
    }

    public function getIndicacionesCliente(): ?string
    {
        return $this->indicaciones_cliente;
    }

    public function setIndicacionesCliente(?string $indicaciones_cliente): self
    {
        $this->indicaciones_cliente = $indicaciones_cliente;

        return $this;
    }

    public function getAveriasDetectadas(): ?string
    {
        return $this->averias_detectadas;
    }

    public function setAveriasDetectadas(?string $averias_detectadas): self
    {
        $this->averias_detectadas = $averias_detectadas;

        return $this;
    }

    public function getDelegacion(): ?delegacion
    {
        return $this->delegacion;
    }

    public function setDelegacion(?delegacion $delegacion): self
    {
        $this->delegacion = $delegacion;

        return $this;
    }


    public function getPrioridad(): ?prioridad
    {
        return $this->prioridad;
    }

    public function setPrioridad(?prioridad $prioridad): self
    {
        $this->prioridad = $prioridad;

        return $this;
    }

    public function getMarca(): ?marca
    {
        return $this->marca;
    }

    public function setMarca(?marca $marca): self
    {
        $this->marca = $marca;

        return $this;
    }

    public function getModelo(): ?Modelo
    {
        return $this->Modelo;
    }

    public function setModelo(?Modelo $Modelo): self
    {
        $this->Modelo = $Modelo;

        return $this;
    }

    public function getPartnumber(): ?partnumber
    {
        return $this->partnumber;
    }

    public function setPartnumber(?partnumber $partnumber): self
    {
        $this->partnumber = $partnumber;

        return $this;
    }

    public function getTipo(): ?tipo
    {
        return $this->tipo;
    }

    public function setTipo(?tipo $tipo): self
    {
        $this->tipo = $tipo;

        return $this;
    }

    public function getFechaEntrada(): ?\DateTimeInterface
    {
        return $this->fecha_entrada;
    }

    public function setFechaEntrada(\DateTimeInterface $fecha_entrada): self
    {
        $this->fecha_entrada = $fecha_entrada;

        return $this;
    }

    public function getFechaSalida(): ?\DateTimeInterface
    {
        return $this->fecha_salida;
    }

    public function setFechaSalida(?\DateTimeInterface $fecha_salida): self
    {
        $this->fecha_salida = $fecha_salida;

        return $this;
    }

    public function getFechaFin(): ?\DateTimeInterface
    {
        return $this->fecha_fin;
    }

    public function setFechaFin(?\DateTimeInterface $fecha_fin): self
    {
        $this->fecha_fin = $fecha_fin;

        return $this;
    }

    public function getPresupuestoAceptado(): ?bool
    {
        return $this->PresupuestoAceptado;
    }

    public function setPresupuestoAceptado(bool $PresupuestoAceptado): self
    {
        $this->PresupuestoAceptado = $PresupuestoAceptado;

        return $this;
    }

    public function getActualizar(): ?bool
    {
        return $this->Actualizar;
    }

    public function setActualizar(?bool $Actualizar): self
    {
        $this->Actualizar = $Actualizar;

        return $this;
    }

    public function getSituacion(): ?situacion
    {
        return $this->situacion;
    }

    public function setSituacion(?situacion $situacion): self
    {
        $this->situacion = $situacion;

        return $this;
    }

    public function getNOrden(): ?string
    {
        return $this->n_orden;
    }

    public function setNOrden(?string $n_orden): self
    {
        $this->n_orden = $n_orden;

        return $this;
    }

    public function getNCaso(): ?string
    {
        return $this->n_caso;
    }

    public function setNCaso(string $n_caso): self
    {
        $this->n_caso = $n_caso;

        return $this;
    }

    public function getColor(): ?string
    {
        return $this->color;
    }

    public function setColor(?string $color): self
    {
        $this->color = $color;

        return $this;
    }

    public function getTrabajosaRealizar(): ?string
    {
        return $this->TrabajosaRealizar;
    }

    public function setTrabajosaRealizar(?string $TrabajosaRealizar): self
    {
        $this->TrabajosaRealizar = $TrabajosaRealizar;

        return $this;
    }

    public function getNSerie(): ?string
    {
        return $this->n_serie;
    }

    public function setNSerie(?string $n_serie): self
    {
        $this->n_serie = $n_serie;

        return $this;
    }

    /**
     * @return Collection|Materiales[]
     */
    public function getMateriales(): Collection
    {
        return $this->materiales;
    }

    public function addMateriale(Materiales $materiale): self
    {
        if (!$this->materiales->contains($materiale)) {
            $this->materiales[] = $materiale;
            $materiale->setOrdenTrabajo($this);
        }

        return $this;
    }

    public function removeMateriale(Materiales $materiale): self
    {
        if ($this->materiales->contains($materiale)) {
            $this->materiales->removeElement($materiale);
            // set the owning side to null (unless already changed)
            if ($materiale->getOrdenTrabajo() === $this) {
                $materiale->setOrdenTrabajo(null);
            }
        }

        return $this;
    }

    public function getObservaciones(): ?string
    {
        return $this->observaciones;
    }

    public function setObservaciones(?string $observaciones): self
    {
        $this->observaciones = $observaciones;

        return $this;
    }

    public function getObservacionesInt(): ?string
    {
        return $this->observaciones_int;
    }

    public function setObservacionesInt(?string $observaciones_int): self
    {
        $this->observaciones_int = $observaciones_int;

        return $this;
    }

    public function getNPresupuesto(): ?string
    {
        return $this->n_presupuesto;
    }

    public function setNPresupuesto(?string $n_presupuesto): self
    {
        $this->n_presupuesto = $n_presupuesto;

        return $this;
    }

    public function getAccesorios(): ?string
    {
        return $this->accesorios;
    }

    public function setAccesorios(?string $accesorios): self
    {
        $this->accesorios = $accesorios;

        return $this;
    }

    public function getFechaCompraEquipo(): ?\DateTimeInterface
    {
        return $this->fechaCompraEquipo;
    }

    public function setFechaCompraEquipo(?\DateTimeInterface $fechaCompraEquipo): self
    {
        $this->fechaCompraEquipo = $fechaCompraEquipo;

        return $this;
    }

}
