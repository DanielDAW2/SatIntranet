<?php declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20190207084912 extends AbstractMigration
{
    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE notas_servicios (id INT AUTO_INCREMENT NOT NULL, usuario_id INT DEFAULT NULL, servicio_id INT NOT NULL, fecha DATETIME NOT NULL, nota VARCHAR(500) NOT NULL, INDEX IDX_62C52E6DDB38439E (usuario_id), INDEX IDX_62C52E6D71CAA3E7 (servicio_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE servicios (id INT AUTO_INCREMENT NOT NULL, tipo_id INT NOT NULL, solicitante_id INT NOT NULL, fecha_alta DATETIME DEFAULT NULL, fecha_fin DATETIME DEFAULT NULL, fecha_baja DATETIME DEFAULT NULL, fecha_renovacion DATETIME DEFAULT NULL, codigo_promo VARCHAR(255) NOT NULL, INDEX IDX_C07E802FA9276E6C (tipo_id), INDEX IDX_C07E802FC680A87 (solicitante_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE tipos_servicios (id INT AUTO_INCREMENT NOT NULL, nombre VARCHAR(50) NOT NULL, slug VARCHAR(50) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('ALTER TABLE notas_servicios ADD CONSTRAINT FK_62C52E6DDB38439E FOREIGN KEY (usuario_id) REFERENCES usuario (id)');
        $this->addSql('ALTER TABLE notas_servicios ADD CONSTRAINT FK_62C52E6D71CAA3E7 FOREIGN KEY (servicio_id) REFERENCES servicios (id)');
        $this->addSql('ALTER TABLE servicios ADD CONSTRAINT FK_C07E802FA9276E6C FOREIGN KEY (tipo_id) REFERENCES tipos_servicios (id)');
        $this->addSql('ALTER TABLE servicios ADD CONSTRAINT FK_C07E802FC680A87 FOREIGN KEY (solicitante_id) REFERENCES usuario (id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE notas_servicios DROP FOREIGN KEY FK_62C52E6D71CAA3E7');
        $this->addSql('ALTER TABLE servicios DROP FOREIGN KEY FK_C07E802FA9276E6C');
        $this->addSql('DROP TABLE notas_servicios');
        $this->addSql('DROP TABLE servicios');
        $this->addSql('DROP TABLE tipos_servicios');
    }
}
