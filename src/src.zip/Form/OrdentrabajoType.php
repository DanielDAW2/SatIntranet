<?php

namespace App\Form;

use App\Entity\Ordentrabajo;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\DateType;

use App\Entity\Serie;
use App\Entity\Situacion;
use App\Entity\Usuario;
use App\Entity\Marca;
use App\Entity\Modelo;
use App\Entity\PartNumber;
use App\Entity\Prioridad;
use App\Entity\Tipo;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class OrdentrabajoType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('n_caso')
            ->add('situacion', EntityType::class,
            [
                "class"=>Situacion::class,
                "choice_label"=>"nombre"
            ]
            )
            ->add('n_orden')
            ->add('fecha_entrada', DateType::class, array(
            "format" => "ddMMyyyy",
            ))
            ->add('indicaciones_cliente', TextareaType::class,
            [
                "attr"=>[
                            "rows"=>5
                        ]

            ])
            ->add('averias_detectadas', TextareaType::class,[
                "attr"=>[
                    "rows"=>5
                ]
            ])
            ->add('TrabajosaRealizar', TextareaType::class,[
                "label"=>"Trabajos a realizar",
                "attr"=>[
                    "rows"=>5
                ]
            ])
            ->add('usuarios', EntityType::class, 
                    [
                        'class'=>Usuario::class,
                        'choices'=> $options["data"]->getDelegacion()->getUsuarios(),
                        'choice_label' => 'nombre',
                        'multiple'     => true,
                        'expanded'=>true,
                        "label"=>"Técnicos:"
                    ])
            ->add('prioridad', EntityType::class, 
                    [
                        'class'=>Prioridad::class,
                        'choice_label' => 'nombre',
                        'choice_value' => 'id_tr'
                        
                    ])
            ->add('n_serie')
            
            ->add('partnumber', TextType::class)
            ->add('marca', TextType::class
            )
            ->add('Modelo', EntityType::class,
            [
                "class"=>Modelo::class,
                "choices"=>$options['data']->getMarca()->getModelos(),
                "choice_label"=>"nombre"
            ])
            ->add('FechaCompraEquipo',TextType::class
            )
            ->add('materiales', CollectionType::class, array(
                'entry_type' => MaterialesType::class,
                'entry_options' => array('label' => false)
            ))
            ->add('observaciones',TextareaType::class,[
                "attr"=>[
                    "rows"=>10
                ]
            ])
            ->add('observaciones_int',TextareaType::class,[
                "attr"=>[
                    "rows"=>10
                ]
            ])
            ->add('color')
            ->add('accesorios');
           
        
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Ordentrabajo::class,
        ]);
    }
}
