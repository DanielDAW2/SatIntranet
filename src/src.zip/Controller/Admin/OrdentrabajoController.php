<?php

namespace App\Controller\Admin;

use App\Entity\Tipo;
use App\Entity\Serie;
use App\Entity\Prioridad;
use App\Entity\Situacion;
use App\Entity\Delegacion;
use App\Entity\Materiales;
use App\Entity\Ordentrabajo;
use App\Entity\Marca;
use App\Entity\Modelo;

use App\Form\OrdentrabajoType;
use App\Repository\OrdentrabajoRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use App\Service\FileUploader;
use Symfony\Component\HttpFoundation\JsonResponse;



/**
 * @isGranted("ROLE_USER")
 * @Route("/ordenestrabajo")
 */
class OrdentrabajoController extends AbstractController
{
    /**
     * @Route("/{page}", 
     * name="ordentrabajo_index", methods={"GET"}, 
     * defaults={"page":"1"},
     * requirements={"page":"\d+"})
     */
    public function index(OrdentrabajoRepository $ordentrabajoRepository, $page=1, Request $req): Response
    {
        $filters = array("delegacion"=>$req->get("delegacion"),"tipo"=>$req->get("tipo"),"situacion"=>$req->get("situacion"));
        if($this->getUser()->getDelegacion()->getId() == 57)
        {
            $result = $ordentrabajoRepository->findAllp($page, 20, $filters);
        } else {
            $result = $ordentrabajoRepository->findByDelegacion($this->getUser()->getDelegacion()->getId(),20, $page, $filters);
        }

        $ordenes = $result['paginator'];
        $Query = $result['query'];
        $maxPages = ceil($result['paginator']->count() / 20);
        return $this->render("ordentrabajo/index.html.twig",[
            'ordentrabajos'=>$ordenes,
            'maxPages'=>$maxPages,
            'thisPage'=>$page,
            'all'=>$Query
                ]);

    }

    /**
     * @Route("/UpdateClinica", name="ordentrabajo_update_clinica", methods={"GET"})
     */
    public function updateClinica()
    {
       $this->updateAllOTClinica($this->getUser()->getDelegacion()->getIdTr());
       return $this->redirectToRoute("ordentrabajo_index");
    }
    
    /**
     * @isGranted("ROLE_CENTRAL", statusCode=403, message="Acceso denegado")
     * @Route("/UpdateAll", name="ordentrabajo_update_all", methods={"GET"})
     */
    public function UpdateAllOts()
    {
        $this->updateAllOT();
        return $this->redirectToRoute("ordentrabajo_index");
    }
    
    /**
     * @Route("/find", name="findOt", methods={"GET"})
     */
    public function findOt(Request $req, OrdentrabajoRepository $ordentrabajoRepository)
    {

        $caso = str_replace(" ","",$req->get("caso"));
        $ot = $this->updateOT($caso);
        if($ot)
        {
            return $this->render("ordentrabajo/index.html.twig",[
                'ordentrabajos'=>$ot,
                'maxPages'=>0,
                'thisPage'=>0,
                'all'=>0
                    ]);
            
        }
        return $this->redirectToRoute("ordentrabajo_index");
        
    }

    /**
     * @isGranted("ROLE_CENTRAL")
     * @Route("/view/{id}/images", name="ordentrabajo_images")
     */
    public function uploadImages(Ordentrabajo $ot = null)
    {
        return $this->render("ordentrabajo/uploadimages.twig",["ordentrabajo"=>$ot]);
    }

    /**
     * @Route("/fileuploadhandler", name="fileuploadhandler")
     * @isGranted("ROLE_CENTRAL")
     */
    public function fileUploadHandler(Request $request, FileUploader $uploader) {
        $output = array('uploaded' => false);
        // get the file from the request object
        $file = $request->files->get('file');
        // generate a new filename (safer, better approach)
        // To use original filename, $fileName = $this->file->getClientOriginalName();
        $ftp = ftp_ssl_connect("213.98.134.69",5000);
        ftp_login($ftp,"ORDER","#ORDERSATIMAGES2019#");
        
        if(!in_array($request->request->get("SERIE").$request->request->get("N_ORDEN"),ftp_nlist($ftp,".")))
        {
            ftp_mkdir($ftp,$request->request->get("SERIE").$request->request->get("N_ORDEN"));
        }

        ftp_put($ftp,$request->request->get("SERIE").$request->request->get("N_ORDEN")."/".$file->getClientOriginalName(),$file,FTP_BINARY);
        ftp_close($ftp);
        unlink($file);
        return new JsonResponse($output);
    }

    /**
     * @isGranted("ROLE_ADMIN", statusCode=403, message="Acceso denegado")
     * @Route("/new", name="ordentrabajo_new", methods={"GET","POST"})
     */
    public function new(Request $request): Response
    {
        $ordentrabajo = new Ordentrabajo();
        $form = $this->createForm(OrdentrabajoType::class, $ordentrabajo);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $delegacion = $this->getDoctrine()->getRepository(Delegacion::class)->findOneBy(array("idTr"=>1));
            $ordentrabajo->setDelegacion($delegacion);
            $entityManager->persist($ordentrabajo);
            $entityManager->flush();

            return $this->redirectToRoute('ordentrabajo_index');
        }

        return $this->render('ordentrabajo/new.html.twig', [
            'ordentrabajo' => $ordentrabajo,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/view/{id}", name="ordentrabajo_show", methods={"GET"})
     */
    public function show(Ordentrabajo $ordentrabajo, Request $request): Response
    {
        $this->updateOT($ordentrabajo->getNOrden());

        $ftp = ftp_ssl_connect("213.98.134.69",5000);


        ftp_login($ftp,"PR","#PR22/01/2019#RT");

        $ftplist = ftp_nlist($ftp,"/");
        ftp_close($ftp);

        $result = in_array("/PRESUPUESTOS_TF_".$ordentrabajo->getNPresupuesto().".pdf",$ftplist);
        
        $form = $this->createForm(OrdentrabajoType::class, $ordentrabajo);

        if(count((array)$ordentrabajo->getMateriales()==0))
        {
            $form->remove('materiales');
        }

        return $this->render('ordentrabajo/edit.html.twig', [
            'ordentrabajo' => $ordentrabajo,
            'form' => $form->createView(),
            'budget' => $result
        ]);
    }

    /**
     * @Route("/view/{id}/budget", name="ordentrabajo_budget")
    */
    public function getOrderBudget(Ordentrabajo $ordentrabajo)
    {
        $ftp = ftp_ssl_connect("213.98.134.69",5000);


        ftp_login($ftp,"PR","#PR22/01/2019#RT");

        $file = ftp_get($ftp,$this->getParameter("pdf")."/".$ordentrabajo->getNPresupuesto().".pdf","PRESUPUESTOS_TF_".$ordentrabajo->getNPresupuesto().".pdf",FTP_BINARY);
        ftp_close($ftp);

        return $this->file($this->getParameter("pdf")."/".$ordentrabajo->getNPresupuesto().".pdf","PR".$ordentrabajo->getNCaso().".pdf");
    }

    /**
     * @isGranted("ROLE_ADMIN", statusCode=403, message="Acceso denegado")
     * @Route("/view/{id}/edit", name="ordentrabajo_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, Ordentrabajo $ordentrabajo): Response
    {
      //  $this->updateOT($ordentrabajo->getNOrden());
        $form = $this->createForm(OrdentrabajoType::class, $ordentrabajo);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('ordentrabajo_index', [
                'id' => $ordentrabajo->getId(),
            ]);
        }
        if(count((array)$ordentrabajo->getMateriales()==0))
        {
            $form->remove('materiales');
        }

        return $this->render('ordentrabajo/edit.html.twig', [
            'ordentrabajo' => $ordentrabajo,
            'form' => $form->createView(),
        ]);
    }
    
    

    /**
     * @Route("/view/{id}/delete", name="ordentrabajo_delete", methods={"DELETE"})
     */
    public function delete(Request $request, Ordentrabajo $ordentrabajo): Response
    {
        if ($this->isCsrfTokenValid('delete'.$ordentrabajo->getId(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($ordentrabajo);
            $entityManager->flush();
        }

        return $this->redirectToRoute('ordentrabajo_index');
    }
    
    /**
     * @isGranted("ROLE_ADMIN", statusCode=403, message="Acceso denegado")
     * @Route("/{id}/import", name="order_import", methods={"GET"})
     */
    public function importOrder(Ordentrabajo $ot)
    {
        $em = $this->getDoctrine()->getManager();
        $data = json_decode(file_get_contents("http://213.98.134.69/ot?order=".$ot->getNCaso()),true);
        if(!empty($data))
        {
            $data = $data[0];
            $ot->setNOrden($data["N_ORDEN_TRABAJO"]);
            $em->persist($ot);
            $em->flush();
            return $this->render('ordentrabajo/show.html.twig', [
            'ordentrabajo' => $ot,
        ]);
        }else
        {
            $datos_post = http_build_query(
            array(
                    'delegacion' => $ot->getDelegacion()->getIdTr(),
                    'serie' => $ot->getSerie()->getIdTr(),
                    'tipo'=>$ot->getTipo()->getIdTr(),
                    'situacion'=>$ot->getSituacion()->getIdTr(),
                    'prioridad'=>$ot->getPrioridad()->getIdTr(),
                    'fechaentrada'=>$ot->getFechaEntrada()->format("Y-m-d"),
                    'indicaciones-cliente'=>$ot->getIndicacionesCliente(),
                    'averias'=>$ot->getAveriasDetectadas(),
                    'poblaciones'=>$ot->getDelegacion()->getPoblacion(),
                    'direccion'=>$ot->getDelegacion()->getDireccion(),
                    'email'=>$ot->getDelegacion()->getEmail(),
                    'telefono'=>$ot->getDelegacion()->getTelefono(),
                    'provincia'=>$ot->getDelegacion()->getProvincia(),
                    'caso'=>$ot->getNCaso(),
                    'nserie'=>$ot->getNSerie() ? $ot->getNSerie() : "",
                    'marca'=>$ot->getMarca() ? $ot->getMarca()->getNombre() : "",
                    'modelo'=>$ot->getModelo() ? $ot->getModelo()->getNombre() : "",
                    'trabajos'=>$ot->getTrabajosaRealizar() ? $ot->getTrabajosaRealizar() : "",
                )
            );
            $opciones = array('http' =>
            array(
                'method'  => 'POST',
                'header'  => 'Content-type: application/x-www-form-urlencoded',
                'content' => $datos_post
                )
            );

            $contexto = stream_context_create($opciones);

            $resultado = file_get_contents('http://213.98.134.69/ot/insert/new', false, $contexto);

            $data = json_decode($resultado, true);
            
            
            $ot->setNOrden($data[0]["N_ORDEN_TRABAJO"]);
             $em->persist($ot);
            $em->flush();
            }  
           
        
    return $this->render('ordentrabajo/show.html.twig', [
            'ordentrabajo' => $ot,
        ]);
    }
    

    public function updateOT($caso)
    {
        
        $data = json_decode(file_get_contents("http://213.98.134.69/ot?order=".$caso), true);
        $ot = array();
        if(!empty($data))
        {   
            foreach($data as $value)
            {
                $em = $this->getDoctrine()->getManager();
                if(!$ordentrabajo = $this->getDoctrine()->getRepository(Ordentrabajo::class)->findOneBy(array("n_orden"=>$value["N_ORDEN_TRABAJO"])))
                {
                    $ordentrabajo =  new Ordentrabajo();
                }
                $ordentrabajo = $this->mergeData($ordentrabajo, $value);
                $em->persist($ordentrabajo);
                $em->flush();
                
                $datam = json_decode(file_get_contents("http://213.98.134.69/ot/mats?order=".$ordentrabajo->getNOrden()), true);
                if(!empty($datam))
                {
                    foreach ($datam as $valuem)
                    {
                        if(!$this->getDoctrine()->getRepository(Materiales::class)->findOneBy(["id_linea_presupuesto"=>$valuem["ID_LINEAS_PRESUPUESTOS"]]))
                        {
                            for($i=0;$i<$valuem["CANTIDAD"];$i++)
                            {

                                $mat = new Materiales();
                                $mat->setNombre($valuem["DESCRIPCION"]);
                                $mat->setIdLineaPresupuesto($valuem["ID_LINEAS_PRESUPUESTOS"]);
                                $mat->setOrdenTrabajo($ordentrabajo);
                                $em->persist($mat);
                                $em->flush();
                                
                            }
                        }
                    }  
                }
                $ot[]=$ordentrabajo;
            }
            
        }
        else
        {
            return null;
        }
        
        return $ot;
        
    }
    /**
     * @isGranted("ROLE_CENTRAL", statusCode=403, message="Acceso denegado")
    */
    public function updateAllOT()
    {
        
        $data = json_decode(file_get_contents("http://213.98.134.69/ot/getALL"), true);
        if(!empty($data))
        {   
            foreach($data as $value)
            {
                $em = $this->getDoctrine()->getManager();
                if(!$ordentrabajo = $this->getDoctrine()->getRepository(Ordentrabajo::class)->findOneBy(array("n_orden"=>$value["N_ORDEN_TRABAJO"])))
                {
                    $ordentrabajo =  new Ordentrabajo();
                }
                $ordentrabajo = $this->mergeData($ordentrabajo, $value);
                $em->persist($ordentrabajo);
                $em->flush();
            }
        }
        else
        {
            return null;
        }
        
        return $ordentrabajo;
        
    }
    public function updateAllOTClinica($clinica)
    {
        
        $data = json_decode(file_get_contents("http://213.98.134.69/ot/getALL/clinica?clinica=$clinica"), true);
        if(!empty($data))
        {   
            $this->getDoctrine()->getRepository(Ordentrabajo::class)->reset($this->getUser()->getDelegacion()->getId());
            foreach($data as $value)
            {
                $em = $this->getDoctrine()->getManager();
                if(!$ordentrabajo = $this->getDoctrine()->getRepository(Ordentrabajo::class)->findOneBy(array("n_orden"=>$value["N_ORDEN_TRABAJO"])))
                {
                    $ordentrabajo =  new Ordentrabajo();
                }
                $ordentrabajo = $this->mergeData($ordentrabajo, $value);
                $em->persist($ordentrabajo);
                
            }
            $em->flush();
        }
        else
        {
            return null;
        }
        
        return $ordentrabajo;
        
    }
    
    public function mergeData(Ordentrabajo $ordentrabajo, array $value)
    {
        $marca = $this->getDoctrine()->getRepository(Marca::class)->findOneBy(["nombre"=>strtoupper($value["CAMPOCONFC3"])]);
        $modelo = $this->getDoctrine()->getRepository(Modelo::class)->findOneBy(["nombre"=>strtoupper($value["CAMPOCONFC4"])]);

        if(!$marca)
        {
            $marca = new Marca();
            $marca->setNombre(strtoupper($value["CAMPOCONFC3"]));
            
        }
        if(!$modelo)
        {
            $modelo = new Modelo();
            $modelo->setNombre(strtoupper($value["CAMPOCONFC4"]));
            $modelo->setMarca($marca);
        }

        $ordentrabajo->setMarca($marca);
        $ordentrabajo->setModelo($modelo);
        $ordentrabajo->setSituacion($this->getDoctrine()->getRepository(Situacion::class)->findOneBy(["idTr"=>$value["ID_SAT_ORDEN_SITUACION"]]));
        $ordentrabajo->setSerie($this->getDoctrine()->getRepository(Serie::class)->findOneBy(["idTr"=>$value["ID_SERIES"]]));
        $ordentrabajo->setIndicacionesCliente($value["INDICACIONES_CLIENTE"]);
        $ordentrabajo->setNOrden($value["N_ORDEN_TRABAJO"]);
        $ordentrabajo->setFechaEntrada(date_create_from_format("Y-m-d", $value["FECHA_ENTRADA"]));
        $ordentrabajo->setFechaSalida($value["FECHA_SALIDA"] ? date_create_from_format("Y-m-d", $value["FECHA_SALIDA"]) : NULL);
        $ordentrabajo->setNCaso($value["CAMPOCONFC1"]);
        $ordentrabajo->setAveriasDetectadas($value["AVERIAS_DETECTADAS"]);
        $ordentrabajo->setTrabajosaRealizar($value["TRABAJOS_AREALIZAR"]);
        $ordentrabajo->setObservaciones($value["OBSERVACIONES"]);
        $ordentrabajo->setObservacionesInt($value["OBSERVACIONES_INT"]);
        $ordentrabajo->setNPresupuesto($value["N_PRESUPUESTO"]);
        $ordentrabajo->setDelegacion($this->getDoctrine()->getRepository(Delegacion::class)->findOneBy(["idTr"=>$value["ID_CLIDIRECCIONES"]]));
        $ordentrabajo->setPrioridad($this->getDoctrine()->getRepository(Prioridad::class)->findOneBy(array("idTr"=>$value["ID_SAT_ORDPRIORIDAD"])));
        $ordentrabajo->setTipo($this->getDoctrine()->getRepository(Tipo::class)->findOneBy(array("idTr"=>$value["ID_SAT_ORDTIPO"])));
        
        return $ordentrabajo;
        
        
    }






}
